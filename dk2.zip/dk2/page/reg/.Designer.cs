﻿namespace dk2.page
{
    partial class PageRegStu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiLabel4 = new Sunny.UI.UILabel();
            this.uiLabel5 = new Sunny.UI.UILabel();
            this.uiLabel6 = new Sunny.UI.UILabel();
            this.uiRadioButtonFemale = new Sunny.UI.UIRadioButton();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.uiTableLayoutPanel1 = new Sunny.UI.UITableLayoutPanel();
            this.uiTextBoxRegName = new Sunny.UI.UITextBox();
            this.uiTextBoxRegDirection = new Sunny.UI.UITextBox();
            this.uiTextBoxRegStuId = new Sunny.UI.UITextBox();
            this.uiTextBoxRegPhone = new Sunny.UI.UITextBox();
            this.uiRadioButtonMale = new Sunny.UI.UIRadioButton();
            this.uiLabel7 = new Sunny.UI.UILabel();
            this.uiTextBoxRegTeacher = new Sunny.UI.UITextBox();
            this.uiTextBoxRegPassword = new Sunny.UI.UITextBox();
            this.uiTableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiLabel1
            // 
            this.uiLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel1.Location = new System.Drawing.Point(3, 0);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(180, 40);
            this.uiLabel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel1.TabIndex = 0;
            this.uiLabel1.Text = "姓名:";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel2
            // 
            this.uiLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel2.Location = new System.Drawing.Point(3, 40);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(180, 47);
            this.uiLabel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel2.TabIndex = 1;
            this.uiLabel2.Text = "性别:";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel3
            // 
            this.uiLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel3.Location = new System.Drawing.Point(3, 87);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(180, 51);
            this.uiLabel3.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel3.TabIndex = 2;
            this.uiLabel3.Text = "手机号:";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel3.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel4
            // 
            this.uiLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel4.Location = new System.Drawing.Point(3, 204);
            this.uiLabel4.Name = "uiLabel4";
            this.uiLabel4.Size = new System.Drawing.Size(180, 49);
            this.uiLabel4.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel4.TabIndex = 3;
            this.uiLabel4.Text = "研究方向:";
            this.uiLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel4.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel5
            // 
            this.uiLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel5.Location = new System.Drawing.Point(3, 138);
            this.uiLabel5.Name = "uiLabel5";
            this.uiLabel5.Size = new System.Drawing.Size(180, 66);
            this.uiLabel5.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel5.TabIndex = 4;
            this.uiLabel5.Text = "学号:";
            this.uiLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel5.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel6
            // 
            this.uiLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel6.Location = new System.Drawing.Point(3, 253);
            this.uiLabel6.Name = "uiLabel6";
            this.uiLabel6.Size = new System.Drawing.Size(180, 62);
            this.uiLabel6.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel6.TabIndex = 5;
            this.uiLabel6.Text = "导师:";
            this.uiLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel6.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiRadioButtonFemale
            // 
            this.uiRadioButtonFemale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButtonFemale.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiRadioButtonFemale.Location = new System.Drawing.Point(337, 72);
            this.uiRadioButtonFemale.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButtonFemale.Name = "uiRadioButtonFemale";
            this.uiRadioButtonFemale.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButtonFemale.Size = new System.Drawing.Size(150, 29);
            this.uiRadioButtonFemale.Style = Sunny.UI.UIStyle.Custom;
            this.uiRadioButtonFemale.TabIndex = 12;
            this.uiRadioButtonFemale.Text = "女";
            this.uiRadioButtonFemale.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiButton1
            // 
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1.Location = new System.Drawing.Point(277, 387);
            this.uiButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.Size = new System.Drawing.Size(181, 46);
            this.uiButton1.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton1.TabIndex = 13;
            this.uiButton1.Text = "注册";
            this.uiButton1.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton1.Click += new System.EventHandler(this.uiButton1_Click);
            // 
            // uiTableLayoutPanel1
            // 
            this.uiTableLayoutPanel1.ColumnCount = 1;
            this.uiTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel7, 0, 6);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel2, 0, 1);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel3, 0, 2);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel5, 0, 3);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel6, 0, 5);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel1, 0, 0);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel4, 0, 4);
            this.uiTableLayoutPanel1.Location = new System.Drawing.Point(32, 14);
            this.uiTableLayoutPanel1.Name = "uiTableLayoutPanel1";
            this.uiTableLayoutPanel1.RowCount = 7;
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.Size = new System.Drawing.Size(186, 359);
            this.uiTableLayoutPanel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiTableLayoutPanel1.TabIndex = 14;
            this.uiTableLayoutPanel1.TagString = null;
            // 
            // uiTextBoxRegName
            // 
            this.uiTextBoxRegName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegName.Location = new System.Drawing.Point(226, 14);
            this.uiTextBoxRegName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegName.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegName.Name = "uiTextBoxRegName";
            this.uiTextBoxRegName.ShowText = false;
            this.uiTextBoxRegName.Size = new System.Drawing.Size(312, 40);
            this.uiTextBoxRegName.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegName.TabIndex = 6;
            this.uiTextBoxRegName.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegName.Watermark = "";
            this.uiTextBoxRegName.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegDirection
            // 
            this.uiTextBoxRegDirection.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegDirection.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegDirection.Location = new System.Drawing.Point(225, 225);
            this.uiTextBoxRegDirection.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegDirection.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegDirection.Name = "uiTextBoxRegDirection";
            this.uiTextBoxRegDirection.ShowText = false;
            this.uiTextBoxRegDirection.Size = new System.Drawing.Size(313, 43);
            this.uiTextBoxRegDirection.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegDirection.TabIndex = 9;
            this.uiTextBoxRegDirection.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegDirection.Watermark = "";
            this.uiTextBoxRegDirection.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegStuId
            // 
            this.uiTextBoxRegStuId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegStuId.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegStuId.Location = new System.Drawing.Point(225, 165);
            this.uiTextBoxRegStuId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegStuId.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegStuId.Name = "uiTextBoxRegStuId";
            this.uiTextBoxRegStuId.ShowText = false;
            this.uiTextBoxRegStuId.Size = new System.Drawing.Size(313, 50);
            this.uiTextBoxRegStuId.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegStuId.TabIndex = 8;
            this.uiTextBoxRegStuId.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegStuId.Watermark = "";
            this.uiTextBoxRegStuId.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegPhone
            // 
            this.uiTextBoxRegPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegPhone.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegPhone.Location = new System.Drawing.Point(226, 109);
            this.uiTextBoxRegPhone.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegPhone.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegPhone.Name = "uiTextBoxRegPhone";
            this.uiTextBoxRegPhone.ShowText = false;
            this.uiTextBoxRegPhone.Size = new System.Drawing.Size(312, 43);
            this.uiTextBoxRegPhone.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegPhone.TabIndex = 7;
            this.uiTextBoxRegPhone.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegPhone.Watermark = "";
            this.uiTextBoxRegPhone.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiRadioButtonMale
            // 
            this.uiRadioButtonMale.Checked = true;
            this.uiRadioButtonMale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButtonMale.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiRadioButtonMale.Location = new System.Drawing.Point(226, 72);
            this.uiRadioButtonMale.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButtonMale.Name = "uiRadioButtonMale";
            this.uiRadioButtonMale.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButtonMale.Size = new System.Drawing.Size(150, 29);
            this.uiRadioButtonMale.Style = Sunny.UI.UIStyle.Custom;
            this.uiRadioButtonMale.TabIndex = 11;
            this.uiRadioButtonMale.Text = "男";
            this.uiRadioButtonMale.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel7
            // 
            this.uiLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel7.Location = new System.Drawing.Point(3, 315);
            this.uiLabel7.Name = "uiLabel7";
            this.uiLabel7.Size = new System.Drawing.Size(180, 44);
            this.uiLabel7.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel7.TabIndex = 6;
            this.uiLabel7.Text = "密码:";
            this.uiLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel7.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegTeacher
            // 
            this.uiTextBoxRegTeacher.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegTeacher.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegTeacher.Location = new System.Drawing.Point(226, 280);
            this.uiTextBoxRegTeacher.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegTeacher.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegTeacher.Name = "uiTextBoxRegTeacher";
            this.uiTextBoxRegTeacher.ShowText = false;
            this.uiTextBoxRegTeacher.Size = new System.Drawing.Size(312, 43);
            this.uiTextBoxRegTeacher.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegTeacher.TabIndex = 15;
            this.uiTextBoxRegTeacher.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegTeacher.Watermark = "";
            this.uiTextBoxRegTeacher.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegPassword
            // 
            this.uiTextBoxRegPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegPassword.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegPassword.Location = new System.Drawing.Point(225, 333);
            this.uiTextBoxRegPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegPassword.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegPassword.Name = "uiTextBoxRegPassword";
            this.uiTextBoxRegPassword.PasswordChar = '*';
            this.uiTextBoxRegPassword.ShowText = false;
            this.uiTextBoxRegPassword.Size = new System.Drawing.Size(313, 43);
            this.uiTextBoxRegPassword.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegPassword.TabIndex = 10;
            this.uiTextBoxRegPassword.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegPassword.Watermark = "";
            this.uiTextBoxRegPassword.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // PageRegStu
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.uiTextBoxRegTeacher);
            this.Controls.Add(this.uiTableLayoutPanel1);
            this.Controls.Add(this.uiButton1);
            this.Controls.Add(this.uiRadioButtonFemale);
            this.Controls.Add(this.uiRadioButtonMale);
            this.Controls.Add(this.uiTextBoxRegPassword);
            this.Controls.Add(this.uiTextBoxRegDirection);
            this.Controls.Add(this.uiTextBoxRegStuId);
            this.Controls.Add(this.uiTextBoxRegPhone);
            this.Controls.Add(this.uiTextBoxRegName);
            this.Name = "PageRegStu";
            this.PageIndex = 1001;
            this.Text = "注册学生";
            this.Resize += new System.EventHandler(this.PageRegStu_Resize);
            this.uiTableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UILabel uiLabel1;
        private Sunny.UI.UILabel uiLabel2;
        private Sunny.UI.UILabel uiLabel3;
        private Sunny.UI.UILabel uiLabel4;
        private Sunny.UI.UILabel uiLabel5;
        private Sunny.UI.UILabel uiLabel6;
        private Sunny.UI.UIRadioButton uiRadioButtonFemale;
        private Sunny.UI.UIButton uiButton1;
        private Sunny.UI.UITableLayoutPanel uiTableLayoutPanel1;
        private Sunny.UI.UITextBox uiTextBoxRegName;
        private Sunny.UI.UITextBox uiTextBoxRegDirection;
        private Sunny.UI.UITextBox uiTextBoxRegStuId;
        private Sunny.UI.UITextBox uiTextBoxRegPhone;
        private Sunny.UI.UIRadioButton uiRadioButtonMale;
        private Sunny.UI.UILabel uiLabel7;
        private Sunny.UI.UITextBox uiTextBoxRegTeacher;
        private Sunny.UI.UITextBox uiTextBoxRegPassword;
    }
}