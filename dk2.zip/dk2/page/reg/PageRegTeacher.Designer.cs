﻿namespace dk2.page
{
    partial class PageRegTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiTableLayoutPanel1 = new Sunny.UI.UITableLayoutPanel();
            this.uiLabel7 = new Sunny.UI.UILabel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiLabel5 = new Sunny.UI.UILabel();
            this.uiLabel6 = new Sunny.UI.UILabel();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiLabel4 = new Sunny.UI.UILabel();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.uiRadioButtonTFemale = new Sunny.UI.UIRadioButton();
            this.uiRadioButtonTMale = new Sunny.UI.UIRadioButton();
            this.uiTextBoxRegOrg = new Sunny.UI.UITextBox();
            this.uiTextBoxRegTDirection = new Sunny.UI.UITextBox();
            this.uiTextBoxRegTId = new Sunny.UI.UITextBox();
            this.uiTextBoxRegTPhone = new Sunny.UI.UITextBox();
            this.uiTextBoxRegTName = new Sunny.UI.UITextBox();
            this.uiTextBoxRegTPassword = new Sunny.UI.UITextBox();
            this.uiTableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiTableLayoutPanel1
            // 
            this.uiTableLayoutPanel1.ColumnCount = 1;
            this.uiTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel7, 0, 6);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel2, 0, 1);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel3, 0, 2);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel5, 0, 3);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel6, 0, 5);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel1, 0, 0);
            this.uiTableLayoutPanel1.Controls.Add(this.uiLabel4, 0, 4);
            this.uiTableLayoutPanel1.Location = new System.Drawing.Point(12, 26);
            this.uiTableLayoutPanel1.Name = "uiTableLayoutPanel1";
            this.uiTableLayoutPanel1.RowCount = 7;
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.uiTableLayoutPanel1.Size = new System.Drawing.Size(187, 345);
            this.uiTableLayoutPanel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiTableLayoutPanel1.TabIndex = 23;
            this.uiTableLayoutPanel1.TagString = null;
            // 
            // uiLabel7
            // 
            this.uiLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel7.Location = new System.Drawing.Point(3, 284);
            this.uiLabel7.Name = "uiLabel7";
            this.uiLabel7.Size = new System.Drawing.Size(181, 52);
            this.uiLabel7.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel7.TabIndex = 6;
            this.uiLabel7.Text = "密码:";
            this.uiLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel7.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel2
            // 
            this.uiLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel2.Location = new System.Drawing.Point(3, 42);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(181, 51);
            this.uiLabel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel2.TabIndex = 1;
            this.uiLabel2.Text = "性别:";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel3
            // 
            this.uiLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel3.Location = new System.Drawing.Point(3, 93);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(181, 45);
            this.uiLabel3.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel3.TabIndex = 2;
            this.uiLabel3.Text = "手机号:";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel3.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel5
            // 
            this.uiLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel5.Location = new System.Drawing.Point(3, 138);
            this.uiLabel5.Name = "uiLabel5";
            this.uiLabel5.Size = new System.Drawing.Size(181, 47);
            this.uiLabel5.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel5.TabIndex = 4;
            this.uiLabel5.Text = "工号:";
            this.uiLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel5.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel6
            // 
            this.uiLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel6.Location = new System.Drawing.Point(3, 242);
            this.uiLabel6.Name = "uiLabel6";
            this.uiLabel6.Size = new System.Drawing.Size(181, 42);
            this.uiLabel6.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel6.TabIndex = 5;
            this.uiLabel6.Text = "所属单位:";
            this.uiLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel6.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel1
            // 
            this.uiLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel1.Location = new System.Drawing.Point(3, 0);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(181, 42);
            this.uiLabel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel1.TabIndex = 0;
            this.uiLabel1.Text = "姓名:";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel4
            // 
            this.uiLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.uiLabel4.Location = new System.Drawing.Point(3, 185);
            this.uiLabel4.Name = "uiLabel4";
            this.uiLabel4.Size = new System.Drawing.Size(181, 57);
            this.uiLabel4.Style = Sunny.UI.UIStyle.Custom;
            this.uiLabel4.TabIndex = 3;
            this.uiLabel4.Text = "研究方向:";
            this.uiLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiLabel4.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiButton1
            // 
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1.Location = new System.Drawing.Point(258, 378);
            this.uiButton1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.Size = new System.Drawing.Size(181, 46);
            this.uiButton1.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton1.TabIndex = 22;
            this.uiButton1.Text = "注册";
            this.uiButton1.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiButton1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.uiButton1.Click += new System.EventHandler(this.uiButton1_Click);
            // 
            // uiRadioButtonTFemale
            // 
            this.uiRadioButtonTFemale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButtonTFemale.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiRadioButtonTFemale.Location = new System.Drawing.Point(336, 80);
            this.uiRadioButtonTFemale.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButtonTFemale.Name = "uiRadioButtonTFemale";
            this.uiRadioButtonTFemale.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButtonTFemale.Size = new System.Drawing.Size(150, 29);
            this.uiRadioButtonTFemale.Style = Sunny.UI.UIStyle.Custom;
            this.uiRadioButtonTFemale.TabIndex = 21;
            this.uiRadioButtonTFemale.Text = "女";
            this.uiRadioButtonTFemale.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiRadioButtonTMale
            // 
            this.uiRadioButtonTMale.Checked = true;
            this.uiRadioButtonTMale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButtonTMale.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiRadioButtonTMale.Location = new System.Drawing.Point(206, 80);
            this.uiRadioButtonTMale.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiRadioButtonTMale.Name = "uiRadioButtonTMale";
            this.uiRadioButtonTMale.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButtonTMale.Size = new System.Drawing.Size(150, 29);
            this.uiRadioButtonTMale.Style = Sunny.UI.UIStyle.Custom;
            this.uiRadioButtonTMale.TabIndex = 20;
            this.uiRadioButtonTMale.Text = "男";
            this.uiRadioButtonTMale.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegOrg
            // 
            this.uiTextBoxRegOrg.ButtonRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegOrg.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegOrg.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegOrg.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegOrg.Location = new System.Drawing.Point(206, 268);
            this.uiTextBoxRegOrg.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegOrg.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegOrg.Name = "uiTextBoxRegOrg";
            this.uiTextBoxRegOrg.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegOrg.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegOrg.ShowText = false;
            this.uiTextBoxRegOrg.Size = new System.Drawing.Size(313, 42);
            this.uiTextBoxRegOrg.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegOrg.TabIndex = 19;
            this.uiTextBoxRegOrg.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegOrg.Watermark = "";
            this.uiTextBoxRegOrg.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegTDirection
            // 
            this.uiTextBoxRegTDirection.ButtonRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTDirection.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegTDirection.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTDirection.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegTDirection.Location = new System.Drawing.Point(206, 223);
            this.uiTextBoxRegTDirection.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegTDirection.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegTDirection.Name = "uiTextBoxRegTDirection";
            this.uiTextBoxRegTDirection.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTDirection.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTDirection.ShowText = false;
            this.uiTextBoxRegTDirection.Size = new System.Drawing.Size(313, 35);
            this.uiTextBoxRegTDirection.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegTDirection.TabIndex = 18;
            this.uiTextBoxRegTDirection.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegTDirection.Watermark = "";
            this.uiTextBoxRegTDirection.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegTId
            // 
            this.uiTextBoxRegTId.ButtonRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegTId.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTId.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegTId.Location = new System.Drawing.Point(206, 175);
            this.uiTextBoxRegTId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegTId.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegTId.Name = "uiTextBoxRegTId";
            this.uiTextBoxRegTId.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTId.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTId.ShowText = false;
            this.uiTextBoxRegTId.Size = new System.Drawing.Size(313, 38);
            this.uiTextBoxRegTId.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegTId.TabIndex = 17;
            this.uiTextBoxRegTId.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegTId.Watermark = "";
            this.uiTextBoxRegTId.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegTPhone
            // 
            this.uiTextBoxRegTPhone.ButtonRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegTPhone.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTPhone.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegTPhone.Location = new System.Drawing.Point(206, 127);
            this.uiTextBoxRegTPhone.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegTPhone.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegTPhone.Name = "uiTextBoxRegTPhone";
            this.uiTextBoxRegTPhone.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTPhone.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTPhone.ShowText = false;
            this.uiTextBoxRegTPhone.Size = new System.Drawing.Size(313, 38);
            this.uiTextBoxRegTPhone.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegTPhone.TabIndex = 16;
            this.uiTextBoxRegTPhone.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegTPhone.Watermark = "";
            this.uiTextBoxRegTPhone.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegTName
            // 
            this.uiTextBoxRegTName.ButtonRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegTName.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegTName.Location = new System.Drawing.Point(206, 30);
            this.uiTextBoxRegTName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegTName.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegTName.Name = "uiTextBoxRegTName";
            this.uiTextBoxRegTName.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTName.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTName.ShowText = false;
            this.uiTextBoxRegTName.Size = new System.Drawing.Size(313, 42);
            this.uiTextBoxRegTName.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegTName.TabIndex = 15;
            this.uiTextBoxRegTName.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegTName.Watermark = "";
            this.uiTextBoxRegTName.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiTextBoxRegTPassword
            // 
            this.uiTextBoxRegTPassword.ButtonRectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBoxRegTPassword.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTPassword.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiTextBoxRegTPassword.Location = new System.Drawing.Point(206, 322);
            this.uiTextBoxRegTPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBoxRegTPassword.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBoxRegTPassword.Name = "uiTextBoxRegTPassword";
            this.uiTextBoxRegTPassword.PasswordChar = '*';
            this.uiTextBoxRegTPassword.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(58)))), ((int)(((byte)(92)))));
            this.uiTextBoxRegTPassword.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiTextBoxRegTPassword.ShowText = false;
            this.uiTextBoxRegTPassword.Size = new System.Drawing.Size(313, 40);
            this.uiTextBoxRegTPassword.Style = Sunny.UI.UIStyle.Custom;
            this.uiTextBoxRegTPassword.TabIndex = 24;
            this.uiTextBoxRegTPassword.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTextBoxRegTPassword.Watermark = "";
            this.uiTextBoxRegTPassword.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // PageRegTeacher
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.uiTextBoxRegTPassword);
            this.Controls.Add(this.uiTableLayoutPanel1);
            this.Controls.Add(this.uiButton1);
            this.Controls.Add(this.uiRadioButtonTFemale);
            this.Controls.Add(this.uiRadioButtonTMale);
            this.Controls.Add(this.uiTextBoxRegOrg);
            this.Controls.Add(this.uiTextBoxRegTDirection);
            this.Controls.Add(this.uiTextBoxRegTId);
            this.Controls.Add(this.uiTextBoxRegTPhone);
            this.Controls.Add(this.uiTextBoxRegTName);
            this.Name = "PageRegTeacher";
            this.PageIndex = 1002;
            this.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.Text = "导师注册";
            this.Resize += new System.EventHandler(this.PageRegTeacher_Resize);
            this.uiTableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UITableLayoutPanel uiTableLayoutPanel1;
        private Sunny.UI.UILabel uiLabel2;
        private Sunny.UI.UILabel uiLabel3;
        private Sunny.UI.UILabel uiLabel5;
        private Sunny.UI.UILabel uiLabel6;
        private Sunny.UI.UILabel uiLabel1;
        private Sunny.UI.UILabel uiLabel4;
        private Sunny.UI.UIButton uiButton1;
        private Sunny.UI.UIRadioButton uiRadioButtonTFemale;
        private Sunny.UI.UIRadioButton uiRadioButtonTMale;
        private Sunny.UI.UITextBox uiTextBoxRegOrg;
        private Sunny.UI.UITextBox uiTextBoxRegTDirection;
        private Sunny.UI.UITextBox uiTextBoxRegTId;
        private Sunny.UI.UITextBox uiTextBoxRegTPhone;
        private Sunny.UI.UITextBox uiTextBoxRegTName;
        private Sunny.UI.UILabel uiLabel7;
        private Sunny.UI.UITextBox uiTextBoxRegTPassword;
    }
}